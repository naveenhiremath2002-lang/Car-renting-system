package com.carrental;

import java.sql.Connection;
import java.sql.DriverManager;

public class TestConnection {
    public static void main(String[] args) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Change here if needed
            String url = "jdbc:mysql://localhost:3306/carrental";
            String user = "root";
            String password = "your_password"; // put your MySQL password

            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/carrental","root","naveen@9862");

            System.out.println("Database connection successful!");
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
