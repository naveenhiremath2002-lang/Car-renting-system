package com.carrental;

import java.util.List;

public interface CarDAO {

    void addCar(CarDTO car);
    CarDTO getCarById(int id);
    List<CarDTO> getAllCars();
    void updateCar(CarDTO car);
    void deleteCar(int id);

    void rentCar(int id);
    void returnCar(int id);
}
