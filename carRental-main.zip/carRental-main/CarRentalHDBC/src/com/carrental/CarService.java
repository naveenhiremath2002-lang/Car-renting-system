package com.carrental;

import java.util.List;

public class CarService {

    private CarDAO dao = new CarDAOImpl();

    public void addCar(CarDTO car) {
        if (car.getPricePerDay() <= 0) {
            System.out.println("Invalid price!");
            return;
        }
        dao.addCar(car);
    }

    public CarDTO getCar(int id) {
        return dao.getCarById(id);
    }

    public List<CarDTO> getAllCars() {
        return dao.getAllCars();
    }

    public void updateCar(CarDTO car) {
        dao.updateCar(car);
    }

    public void deleteCar(int id) {
        dao.deleteCar(id);
    }

    public void rentCar(int id) {
        dao.rentCar(id);
    }

    public void returnCar(int id) {
        dao.returnCar(id);
    }
}
