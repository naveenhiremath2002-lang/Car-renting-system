package com.carrental;

import java.sql.*;
import java.util.*;

public class CarDAOImpl implements CarDAO {

    private static final String URL = "jdbc:mysql://localhost:3306/testdb";
    private static final String USER = "root";
    private static final String PASS = "naveen@9862";

    public void addCar(CarDTO car) {
        String sql = "INSERT INTO cars(brand, model, price_per_day, available) VALUES(?,?,?,?)";
        try (Connection con = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setString(1, car.getBrand());
            pst.setString(2, car.getModel());
            pst.setInt(3, car.getPricePerDay());
            pst.setBoolean(4, true);

            pst.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    public CarDTO getCarById(int id) {
        String sql = "SELECT * FROM cars WHERE id=?";
        try (Connection con = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                return new CarDTO(
                        rs.getInt("id"),
                        rs.getString("brand"),
                        rs.getString("model"),
                        rs.getInt("price_per_day"),
                        rs.getBoolean("available")
                );
            }
        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }

    public List<CarDTO> getAllCars() {
        List<CarDTO> list = new ArrayList<>();
        String sql = "SELECT * FROM cars";

        try (Connection con = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement pst = con.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {
                list.add(new CarDTO(
                        rs.getInt("id"),
                        rs.getString("brand"),
                        rs.getString("model"),
                        rs.getInt("price_per_day"),
                        rs.getBoolean("available")
                ));
            }
        } catch (Exception e) { e.printStackTrace(); }

        return list;
    }

    public void updateCar(CarDTO car) {
        String sql = "UPDATE cars SET brand=?, model=?, price_per_day=?, available=? WHERE id=?";
        try (Connection con = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setString(1, car.getBrand());
            pst.setString(2, car.getModel());
            pst.setInt(3, car.getPricePerDay());
            pst.setBoolean(4, car.isAvailable());
            pst.setInt(5, car.getId());

            pst.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    public void deleteCar(int id) {
        String sql = "DELETE FROM cars WHERE id=?";
        try (Connection con = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setInt(1, id);
            pst.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    public void rentCar(int id) {
        String sql = "UPDATE cars SET available=false WHERE id=?";
        try (Connection con = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setInt(1, id);
            pst.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    public void returnCar(int id) {
        String sql = "UPDATE cars SET available=true WHERE id=?";
        try (Connection con = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setInt(1, id);
            pst.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }
}
